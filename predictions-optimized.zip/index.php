<?php
/**
 * Home Feed — Active predictions with filters, search, and pagination.
 */
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/csrf.php';
startSecureSession();

$db = getDB();
$currentUser = getCurrentUser();
$currentUserId = getCurrentUserId();

// ── Quick Stats ──
// [OPTIMIZED] Combined 3 stat queries into 1 using subqueries
$stmtStats = $db->query("
    SELECT
        (SELECT COUNT(*) FROM predictions) AS total_predictions,
        (SELECT COUNT(*) FROM users) AS total_users,
        (SELECT COALESCE(SUM(total_pool_for + total_pool_against), 0) FROM predictions) AS total_pool
");
$stats = $stmtStats->fetch();
$totalPredictions = (int)$stats['total_predictions'];
$totalUsers = (int)$stats['total_users'];
$totalPool = (float)$stats['total_pool'];

// ── Filters ──
$category = trim($_GET['category'] ?? '');
$sort = trim($_GET['sort'] ?? 'newest');
$status = trim($_GET['status'] ?? 'active');
$page = max(1, intval($_GET['page'] ?? 1));
$perPage = 20;
$offset = ($page - 1) * $perPage;

// Build WHERE clause
$where = [];
$params = [];

if ($status && $status !== 'all') {
    $where[] = 'p.status = :status';
    $params[':status'] = $status;
}

if ($category && $category !== 'all') {
    $where[] = 'p.category = :category';
    $params[':category'] = $category;
}

// Shadow ban: hide shadow-banned users' predictions from others
if ($currentUser && (int)$currentUser['is_shadow_banned'] === 1) {
    // Show own predictions + non-shadow-banned
    $where[] = '(u.is_shadow_banned = 0 OR p.user_id = :sbuid)';
    $params[':sbuid'] = $currentUserId;
} else {
    $where[] = 'u.is_shadow_banned = 0';
}

$whereSQL = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

// Order by
switch ($sort) {
    case 'most_bets':
        $orderSQL = 'ORDER BY bet_count DESC, p.created_at DESC';
        break;
    case 'highest_stake':
        $orderSQL = 'ORDER BY (p.total_pool_for + p.total_pool_against) DESC, p.created_at DESC';
        break;
    case 'ending_soon':
        $orderSQL = 'ORDER BY CASE WHEN p.expires_at IS NULL THEN 1 ELSE 0 END, p.expires_at ASC, p.created_at DESC';
        break;
    default: // newest
        $orderSQL = 'ORDER BY p.created_at DESC';
        break;
}

// Count total
$countSQL = "SELECT COUNT(*) AS total
             FROM predictions p
             JOIN users u ON p.user_id = u.id
             $whereSQL";
$stmtCount = $db->prepare($countSQL);
$stmtCount->execute($params);
$totalResults = (int)$stmtCount->fetch()['total'];
$totalPages = max(1, ceil($totalResults / $perPage));

// Fetch predictions
// [OPTIMIZED] Replaced correlated subquery with LEFT JOIN for bet_count
$sql = "SELECT p.*, u.username, u.is_shadow_banned,
               COALESCE(bc.bet_count, 0) AS bet_count
        FROM predictions p
        JOIN users u ON p.user_id = u.id
        LEFT JOIN (SELECT prediction_id, COUNT(*) AS bet_count FROM bets GROUP BY prediction_id) bc
            ON bc.prediction_id = p.id
        $whereSQL
        $orderSQL
        LIMIT :limit OFFSET :offset";
$stmt = $db->prepare($sql);
foreach ($params as $k => $v) {
    $stmt->bindValue($k, $v);
}
$stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$predictions = $stmt->fetchAll();

$categories = getCategoryList();

$pageTitle = 'Home';
$currentPage = 'home';
require_once __DIR__ . '/includes/header.php';
?>

<!-- Hero Section -->
<div class="card mb-4" style="background: linear-gradient(135deg, var(--bg-secondary) 0%, rgba(99,102,241,0.12) 100%); border-color: rgba(99,102,241,0.2);">
    <div class="card-body py-4">
        <div class="row align-items-center">
            <div class="col-lg-7">
                <h1 class="fw-bold mb-2"><i class="fas fa-chart-line text-accent me-2"></i>Prediction Market</h1>
                <p class="text-secondary mb-3 mb-lg-0">
                    Make predictions, place bets, and test your forecasting skills. Earn credits by being right!
                </p>
            </div>
            <div class="col-lg-5">
                <div class="row g-3 text-center">
                    <div class="col-4">
                        <div class="fw-800 fs-4 text-accent"><?= number_format($totalPredictions) ?></div>
                        <div class="small text-muted text-uppercase">Predictions</div>
                    </div>
                    <div class="col-4">
                        <div class="fw-800 fs-4 text-accent"><?= number_format($totalUsers) ?></div>
                        <div class="small text-muted text-uppercase">Users</div>
                    </div>
                    <div class="col-4">
                        <div class="fw-800 fs-4 text-credits"><?= number_format($totalPool, 0) ?></div>
                        <div class="small text-muted text-uppercase">Credits in Play</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Filter Bar -->
<div class="card mb-4">
    <div class="card-body py-3">
        <form method="GET" action="" class="row g-2 align-items-end">
            <div class="col-md-3 col-6">
                <label class="form-label small mb-1"><i class="fas fa-folder me-1"></i>Category</label>
                <select name="category" class="form-select form-select-sm">
                    <option value="all">All Categories</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= sanitize($cat) ?>" <?= $category === $cat ? 'selected' : '' ?>>
                            <?= sanitize($cat) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3 col-6">
                <label class="form-label small mb-1"><i class="fas fa-sort me-1"></i>Sort By</label>
                <select name="sort" class="form-select form-select-sm">
                    <option value="newest" <?= $sort === 'newest' ? 'selected' : '' ?>>Newest</option>
                    <option value="most_bets" <?= $sort === 'most_bets' ? 'selected' : '' ?>>Most Bets</option>
                    <option value="highest_stake" <?= $sort === 'highest_stake' ? 'selected' : '' ?>>Highest Stake</option>
                    <option value="ending_soon" <?= $sort === 'ending_soon' ? 'selected' : '' ?>>Ending Soon</option>
                </select>
            </div>
            <div class="col-md-3 col-6">
                <label class="form-label small mb-1"><i class="fas fa-filter me-1"></i>Status</label>
                <select name="status" class="form-select form-select-sm">
                    <option value="active" <?= $status === 'active' ? 'selected' : '' ?>>Active</option>
                    <option value="all" <?= $status === 'all' ? 'selected' : '' ?>>All</option>
                    <option value="resolved_yes" <?= $status === 'resolved_yes' ? 'selected' : '' ?>>Resolved Yes</option>
                    <option value="resolved_no" <?= $status === 'resolved_no' ? 'selected' : '' ?>>Resolved No</option>
                    <option value="cancelled" <?= $status === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                </select>
            </div>
            <div class="col-md-3 col-6">
                <button type="submit" class="btn btn-primary btn-sm w-100">
                    <i class="fas fa-search me-1"></i>Apply Filters
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Results Count -->
<div class="d-flex justify-content-between align-items-center mb-3">
    <p class="text-secondary mb-0 small">
        Showing <?= number_format($totalResults) ?> prediction<?= $totalResults !== 1 ? 's' : '' ?>
    </p>
    <?php if (isLoggedIn()): ?>
        <a href="<?= SITE_URL ?>/create.php" class="btn btn-primary btn-sm">
            <i class="fas fa-plus me-1"></i>New Prediction
        </a>
    <?php endif; ?>
</div>

<?php if (empty($predictions)): ?>
    <!-- Empty State -->
    <div class="empty-state">
        <div class="empty-state-icon"><i class="fas fa-crystal-ball"></i></div>
        <div class="empty-state-title">No predictions found</div>
        <div class="empty-state-text">
            <?php if ($status !== 'all' || $category): ?>
                Try adjusting your filters or browse all predictions.
            <?php else: ?>
                Be the first to create a prediction and start the conversation!
            <?php endif; ?>
        </div>
        <?php if (isLoggedIn()): ?>
            <a href="<?= SITE_URL ?>/create.php" class="btn btn-primary">
                <i class="fas fa-plus me-1"></i>Create Prediction
            </a>
        <?php endif; ?>
    </div>
<?php else: ?>
    <!-- Prediction Grid -->
    <div class="prediction-grid">
        <?php foreach ($predictions as $pred): ?>
            <?php
                $prob = (int)$pred['probability'];
                $probLevel = $prob < 33 ? 'low' : ($prob < 67 ? 'medium' : 'high');
                $totalPoolPred = (float)$pred['total_pool_for'] + (float)$pred['total_pool_against'];
                $statusLabel = str_replace('_', ' ', $pred['status']);
            ?>
            <div class="prediction-card card">
                <div class="card-body">
                    <!-- Category & Status -->
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <span class="badge <?= getCategoryBadgeClass($pred['category']) ?>">
                            <?= sanitize($pred['category']) ?>
                        </span>
                        <span class="badge <?= getStatusBadgeClass($pred['status']) ?>">
                            <?= sanitize(ucwords($statusLabel)) ?>
                        </span>
                    </div>

                    <!-- Title -->
                    <h5 class="prediction-title">
                        <a href="<?= SITE_URL ?>/prediction.php?id=<?= (int)$pred['id'] ?>">
                            <?= sanitize($pred['title']) ?>
                        </a>
                    </h5>

                    <!-- Description -->
                    <p class="prediction-description">
                        <?= sanitize(truncate($pred['description'], 100)) ?>
                    </p>

                    <!-- Probability Bar -->
                    <div class="probability-bar-wrapper">
                        <div class="probability-label">
                            <span>Probability</span>
                            <span class="probability-value"><?= $prob ?>%</span>
                        </div>
                        <div class="probability-bar">
                            <div class="probability-bar-fill" style="width:<?= $prob ?>%" data-prob="<?= $probLevel ?>"></div>
                        </div>
                    </div>

                    <!-- Meta -->
                    <div class="prediction-meta">
                        <span><i class="fas fa-user"></i> <?= sanitize($pred['username']) ?></span>
                        <span><i class="fas fa-clock"></i> <?= timeAgo($pred['created_at']) ?></span>
                        <?php if ($pred['expires_at']): ?>
                            <span><i class="fas fa-hourglass-half"></i> Ends <?= timeAgo($pred['expires_at']) ?></span>
                        <?php endif; ?>
                    </div>

                    <!-- Stats -->
                    <div class="prediction-stats">
                        <div class="stat-item">
                            <div class="stat-value credit-amount">
                                <i class="fas fa-coins fa-sm"></i> <?= number_format($pred['credit_stake'], 0) ?>
                            </div>
                            <div class="stat-label">Stake</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-value"><?= number_format($totalPoolPred, 0) ?></div>
                            <div class="stat-label">Total Pool</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-value"><?= (int)$pred['bet_count'] ?></div>
                            <div class="stat-label">Bets</div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- Pagination -->
    <?php if ($totalPages > 1): ?>
        <nav class="mt-4">
            <ul class="pagination justify-content-center">
                <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                    <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page - 1])) ?>">
                        <i class="fas fa-chevron-left"></i>
                    </a>
                </li>
                <?php
                    $startP = max(1, $page - 2);
                    $endP = min($totalPages, $page + 2);
                    if ($startP > 1): ?>
                        <li class="page-item"><a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => 1])) ?>">1</a></li>
                        <?php if ($startP > 2): ?><li class="page-item disabled"><span class="page-link">…</span></li><?php endif; ?>
                    <?php endif;
                    for ($i = $startP; $i <= $endP; $i++): ?>
                        <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                            <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>"><?= $i ?></a>
                        </li>
                    <?php endfor;
                    if ($endP < $totalPages): ?>
                        <?php if ($endP < $totalPages - 1): ?><li class="page-item disabled"><span class="page-link">…</span></li><?php endif; ?>
                        <li class="page-item"><a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $totalPages])) ?>"><?= $totalPages ?></a></li>
                    <?php endif; ?>
                <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
                    <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page + 1])) ?>">
                        <i class="fas fa-chevron-right"></i>
                    </a>
                </li>
            </ul>
        </nav>
    <?php endif; ?>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
